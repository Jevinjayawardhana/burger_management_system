import java.util.Scanner;
public class FOOD_MANAGEMENT {

    public static void main(String[] args) {

        System.out.println("");
        System.out.println("-*-*-*-*-*-*-*-*-*-*FOODIES FAVE QUEUE MANAGEMENT SYSTEM*-*-*-*-*-*-*-*-*-*-");
        System.out.println("");


        CLASS_VERSION object = new CLASS_VERSION();
        object.QUEUE();

        boolean done = true;
        while (done) {
            System.out.println("\n");

            System.out.println("||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
            System.out.println("||--------------------------MENU------------------------------||");
            System.out.println("||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
            System.out.println("||  100 or VFQ: View all Queues.                              ||");
            System.out.println("||  101 or VEQ: View all Empty Queues.                        ||");
            System.out.println("||  102 or ACQ: Add customer to a Queue.                      ||");
            System.out.println("||  103 or RCQ: Remove a customer from a Queue.               ||");
            System.out.println("||  104 or PCQ: Remove a served customer.                     ||");
            System.out.println("||  105 or VCS: View Customers Sorted in alphabetical order.  ||");
            System.out.println("||  106 or SPD: Store Program Data into file.                 ||");
            System.out.println("||  107 or LPD: Load Program Data from file.                  ||");
            System.out.println("||  108 or STK: View Remaining burgers Stock.                 ||");
            System.out.println("||  109 or AFS: Add burgers to Stock.                         ||");
            System.out.println("||  110 or IFQ: View Income of Each Queue.                    ||");
            System.out.println("||  111 or DWQ: Display Waiting Queue.                        ||");
            System.out.println("||  999 or EXT: Exit the Program.                             ||");
            System.out.println("||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");

            System.out.println("\n");

            object.BURGER_WARNING();

            Scanner input = new Scanner(System.in);

            System.out.println("--------------------WELCOME TO OUR SHOP---------------------");
            System.out.println("");
            System.out.println("PLEASE ENTER THE NUMBER OR CODE WHAT YOU WANT TO DO : ");
            String task = input.next().toLowerCase();

            //Enhanced switch case to call all methods
            switch (task) {
                case
                        "100",
                                "vfq" -> object.VIEW_ALL_QUEUE();
                case
                        "101",
                                "veq" -> object.VIEW_EMPTY_QUEUE();
                case
                        "102",
                                "acq" -> object. ADD_CUSTOMER();
                case
                        "103",
                                "rcq" -> object. REMOVE_CUSTOMER();
                case
                        "104",
                                "pcq" -> object.REMOVE_SERVED_CUSTOMERS();
                case
                        "105",
                                "vcs" -> object.VIEW_CUSTOMERS();
                case
                        "106",
                                "spd" -> object.ADDING_DATA_TO_FILE();
                case
                        "107",
                                "lpd" -> object.READING_FILE_DATA();
                case
                        "108",
                                "stk" -> object.COUNT_OF_BURGERS();
                case
                        "109",
                                "afs" -> object.BURGER_ADDING();
                case
                        "110",
                                "ifq" -> object.CALCULATE_INCOME();
                case
                        "111",
                                "dwq" -> object.WAITING_QUEUE_SECTION();
                case
                        "999",
                                "ext" -> {
                    object.EXIT();
                    done = false;
                }
                default -> System.out.println("-WRONG-INPUT-");
            }


        }



    }
}