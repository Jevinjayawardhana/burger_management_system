import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;
public class array_version {

    static boolean RUN_PROGRAMME = true;
    static int BURGER_IN_STOCK = 50;
    //star printing method
    static String[] CASHIER_POSITION_1 = {"X", "X"}; //queue1
    static String[] CASHIER_POSITION_2 = {"X", "X", "X"}; //queue2
    static String[] CASHIER_POSITION_3 = {"X", "X", "X", "X", "X"}; //queue3

    //customer positions
    static String[] CUSTOMER_POSITION_1 = new String[2];//adding customer name method
    static String[] CUSTOMER_POSITION_2 = new String[3];
    static String[] CUSTOMER_POSITION_3 = new String[5];

    //it's used to add customer method to remove the out of bound error
    static int CUST_POSI_1 = 0;
    static int CUST_POSI_2 = 0;
    static int CUST_POSI_3 = 0;


    //method to view all queues
    static void VIEW_ALL_QUEUE() {

        System.out.println("");
        System.out.println("*****************");
        System.out.println("*-C-A-S-H-I-E-R-*");
        System.out.println("*****************");
        System.out.printf("%2s %5s %6s %n", CASHIER_POSITION_1[0], CASHIER_POSITION_2[0], CASHIER_POSITION_3[0]);
        System.out.printf("%2s %5s %6s %n", CASHIER_POSITION_1[1], CASHIER_POSITION_2[1], CASHIER_POSITION_3[1]);
        System.out.printf("%8s %6s %n", CASHIER_POSITION_2[2], CASHIER_POSITION_3[2]);
        System.out.printf("%15s %n", CASHIER_POSITION_3[3]);
        System.out.printf("%15s %n", CASHIER_POSITION_3[4]);
        System.out.println("");
    }

    //calling method to empty places
    static void VIEW_EMPTY_QUEUE() {
        boolean QUEUE_1 = false;
        boolean QUEUE_2 = false;
        boolean QUEUE_3 = false;

        System.out.println("*****************");
        System.out.println("*-C-A-S-H-I-E-R-*");
        System.out.println("*****************");

        for (String Element : CASHIER_POSITION_1) {
            if (Element.equals("X")) {
                QUEUE_1 = true;
                break;
            }
        }

        for (String Element : CASHIER_POSITION_2) {
            if (Element.equals("X")) {
                QUEUE_2 = true;
                break;
            }
        }

        for (String Element : CASHIER_POSITION_3) {
            if (Element.equals("X")) {
                QUEUE_3 = true;
                break;
            }
        }
//print empty queue
        if (QUEUE_1 == true && QUEUE_2 == true && QUEUE_3 == true) {
            System.out.printf("%2s %5s %6s %n", CASHIER_POSITION_1[0], CASHIER_POSITION_2[0], CASHIER_POSITION_3[0]);
            System.out.printf("%2s %5s %6s %n", CASHIER_POSITION_1[1], CASHIER_POSITION_2[1], CASHIER_POSITION_3[1]);
            System.out.printf("%8s %6s %n", CASHIER_POSITION_2[2], CASHIER_POSITION_3[2]);
            System.out.printf("%15s %n", CASHIER_POSITION_3[3]);
        } else if (QUEUE_1 == true && QUEUE_2 == true) {
            System.out.printf("%2s %5s %n", CASHIER_POSITION_1[0], CASHIER_POSITION_2[0]);
            System.out.printf("%2s %5s %n", CASHIER_POSITION_1[1], CASHIER_POSITION_2[1]);
            System.out.printf("%8s %6s %n", CASHIER_POSITION_2[2], CASHIER_POSITION_3[2]);
        } else if (QUEUE_2 == true && QUEUE_3 == true) {
            System.out.printf("%2s %11s %n", CASHIER_POSITION_1[0], CASHIER_POSITION_3[0]);
            System.out.printf("%2s %11s %n", CASHIER_POSITION_1[1], CASHIER_POSITION_3[1]);
            System.out.printf("%15s %n", CASHIER_POSITION_3[2]);
            System.out.printf("%15s %n", CASHIER_POSITION_3[3]);
            System.out.printf("%15s %n", CASHIER_POSITION_3[4]);
        } else if (QUEUE_2 == true && QUEUE_3 == true) {
            System.out.printf("%8s %6s %n", CASHIER_POSITION_2[0], CASHIER_POSITION_3[0]);
            System.out.printf("%8s %6s %n", CASHIER_POSITION_2[1], CASHIER_POSITION_3[1]);
            System.out.printf("%8s %6s %n", CASHIER_POSITION_2[2], CASHIER_POSITION_3[2]);
            System.out.printf("%15s %n", CASHIER_POSITION_3[3]);
            System.out.printf("%15s %n", CASHIER_POSITION_3[4]);
        } else if (QUEUE_1 == true) {
            System.out.printf("%2s %n", CASHIER_POSITION_1[0]);
            System.out.printf("%2s %n", CASHIER_POSITION_1[1]);
        } else if (QUEUE_1 == true) {
            System.out.printf("%8s %n", CASHIER_POSITION_2[0], CASHIER_POSITION_3[0]);
            System.out.printf("%8s %n", CASHIER_POSITION_2[1], CASHIER_POSITION_3[1]);
            System.out.printf("%8s %n", CASHIER_POSITION_2[2], CASHIER_POSITION_3[2]);
        } else {
            System.out.printf("%15s %n", CASHIER_POSITION_3[0]);
            System.out.printf("%15s %n", CASHIER_POSITION_3[1]);
            System.out.printf("%15s %n", CASHIER_POSITION_3[2]);
            System.out.printf("%15s %n", CASHIER_POSITION_3[3]);
            System.out.printf("%15s %n", CASHIER_POSITION_3[4]);
        }

    }


    //calling method to change x--->o
    static int COUNT_OF_CUSTOMER(String[] Cashier) {
        int COUNT = 0;

        for (String element : Cashier) {
            if (element.equals("O")) {
                COUNT++;

            }
        }
        return COUNT;
    }

    //adding customers to right place
    static void ADDING_CUSTOMER_NAME(int QUEUE_NUMBER, String NAME) {

        int QUEUE_LENGTH = 0;
        if (QUEUE_NUMBER == 1) {
            QUEUE_LENGTH = 2;
            CUSTOMER_POSITION_1[CUST_POSI_1] = NAME;
            CUST_POSI_1++;


        } else if (QUEUE_NUMBER == 2) {
            QUEUE_LENGTH = 3;
            CUSTOMER_POSITION_2[CUST_POSI_2] = NAME;
            CUST_POSI_2++;


        } else {
            QUEUE_LENGTH = 5;
            CUSTOMER_POSITION_3[CUST_POSI_3] = NAME;
            CUST_POSI_3++;


        }

    }

    //method to add customer
    static void ADD_CUSTOMER() {


        Scanner INPUT_1 = new Scanner(System.in);

        System.out.print("PLEASE ENTER THE CUSTOMER NAME....:");
        String Name = INPUT_1.next();

        int WHAT_QUEUE;

        do {


            System.out.print("WHAT IS THE QUEUE NUMBER YOU WANT TO ADD FROM(1,2,3):");
            WHAT_QUEUE = INPUT_1.nextInt();

            if(WHAT_QUEUE<1 || WHAT_QUEUE>3){
                System.out.println("-INVALID INPUT--PLEASE ENTER A NUMBER FROM(1,2,3..)");
            }

        }while (WHAT_QUEUE<1 || WHAT_QUEUE>3);

        int CASHIER_IS_FULL = 0;


        if (WHAT_QUEUE == 1) {
            CASHIER_IS_FULL = COUNT_OF_CUSTOMER(CASHIER_POSITION_1);

            if (CASHIER_IS_FULL < 2) {
                ADDING_CUSTOMER_NAME(1, Name);

                for (int i = 0; i < CASHIER_POSITION_1.length; i++) {
                    if (CASHIER_POSITION_1[i].equals("X")) {
                        CASHIER_POSITION_1[i] = "O";
                        break;
                    }
                }
            } else {
                System.out.println("");
                System.out.println("QUEUE-IS-FULL....YOU HAVE TO WAIT!");
                System.out.println("");
            }

        } else if (WHAT_QUEUE == 2) {
            CASHIER_IS_FULL = COUNT_OF_CUSTOMER(CASHIER_POSITION_2);

            if (CASHIER_IS_FULL < 3) {
                ADDING_CUSTOMER_NAME(2, Name);

                for (int i = 0; i < CASHIER_POSITION_2.length; i++) {
                    if (CASHIER_POSITION_2[i].equals("X")) {
                        CASHIER_POSITION_2[i] = "O";
                        break;
                    }
                }
            } else {
                System.out.println("");
                System.out.println("QUEUE-IS-FULL....YOU HAVE TO WAIT!");
                System.out.println("");
            }

        } else {
            CASHIER_IS_FULL = COUNT_OF_CUSTOMER(CASHIER_POSITION_3);

            if (CASHIER_IS_FULL < 5) {
                ADDING_CUSTOMER_NAME(3, Name);

                for (int i = 0; i < CASHIER_POSITION_3.length; i++) {
                    if (CASHIER_POSITION_3[i].equals("X")) {
                        CASHIER_POSITION_3[i] = "O";
                        break;
                    }
                }
            } else {
                System.out.println("");
                System.out.println("QUEUE-IS-FULL....YOU HAVE TO WAIT!");
                System.out.println("");
            }
        }

        VIEW_ALL_QUEUE();

    }

    // method to remove a customer in a specific location
    static void REMOVE_CUSTOMER() {
        Scanner INPUT_2 = new Scanner(System.in);

        System.out.print("ENTER THE QUEUE NUMBER OF CUSTOMER THAT YOU WANT TO REMOVE (1,2,3) : ");
        int WHAT_QUEUE = INPUT_2.nextInt();

        System.out.print("WHICH CUSTOMER (PLEASE ENTER POSITION NUMBER OF CUSTOMER):");
        int WHICH_CUSTOMER = INPUT_2.nextInt();


        if (WHAT_QUEUE == 1) {


            for (int i = WHICH_CUSTOMER - 1; i < 1; i++) {
                CASHIER_POSITION_1[i] = CASHIER_POSITION_3[i + 1];

            }
            CASHIER_POSITION_1[1] = "X";
        } else {
            System.out.println("-NO-CUSTOMERS-");


        }
        if (WHAT_QUEUE == 2) {

            if (CASHIER_POSITION_2[WHICH_CUSTOMER] == "O") {

                for (int i = WHICH_CUSTOMER - 1; i < 2; i++) {
                    CASHIER_POSITION_2[i] = CASHIER_POSITION_2[i + 1];

                }
                CASHIER_POSITION_2[2] = "X";

            } else {
                System.out.println("-NO-CUSTOMERS-");
            }

        } else {

            if (CASHIER_POSITION_3[WHICH_CUSTOMER] == "O") {

                for (int i = WHICH_CUSTOMER - 1; i < 4; i++) {
                    CASHIER_POSITION_3[i] = CASHIER_POSITION_3[i + 1];

                }
                CASHIER_POSITION_3[4] = "X";

            } else {
                System.out.println("-NO-CUSTOMERS-");
            }
        }
        VIEW_ALL_QUEUE();
    }


    static void REMOVE_SERVED_CUSTOMERS() {

        BURGER_IN_STOCK -= 5;

        Scanner INPUT_3 = new Scanner(System.in);

        System.out.print("ENTER THE QUEUE NUMBER OF CUSTOMER THAT YOU WANT TO REMOVE (1,2,3) : ");
        int WHAT_QUEUE = INPUT_3.nextInt();

        int COUNT_OF_CUSTOMER = 0;

        if (WHAT_QUEUE == 1) {
            COUNT_OF_CUSTOMER = COUNT_OF_CUSTOMER(CASHIER_POSITION_1);

            if (COUNT_OF_CUSTOMER != 0) {

                for (int i = 0; i < 1; i++) {
                    CASHIER_POSITION_1[i] = CASHIER_POSITION_1[i + 1];

                }
                CASHIER_POSITION_1[1] = "X";

            } else {
                System.out.println("-NO-CUSTOMERS-");
            }

        } else if (WHAT_QUEUE == 2) {
            COUNT_OF_CUSTOMER = COUNT_OF_CUSTOMER(CASHIER_POSITION_2);

            if (COUNT_OF_CUSTOMER != 0) {

                for (int i = 0; i < 2; i++) {
                    CASHIER_POSITION_2[i] = CASHIER_POSITION_2[i + 1];

                }
                CASHIER_POSITION_2[2] = "x";

            } else {
                System.out.println("-NO-CUSTOMERS-");
            }

        } else {
            COUNT_OF_CUSTOMER = COUNT_OF_CUSTOMER(CASHIER_POSITION_3);

            if (COUNT_OF_CUSTOMER != 0) {

                for (int i = 0; i < 4; i++) {
                    CASHIER_POSITION_3[i] = CASHIER_POSITION_3[i + 1];

                }
                CASHIER_POSITION_3[4] = "X";

            } else {
                System.out.println("-NO-CUSTOMERS-");
            }
        }
        VIEW_ALL_QUEUE();
    }

    public static String[] combineArrays(String[]... arrays) {
        int totalLength = 0;
        for (String[] array : arrays) {
            for (String element : array) {
                if (element != null) {
                    totalLength++;
                }
            }
        }

        String[] combinedArray = new String[totalLength];
        int currentIndex = 0;
        for (String[] array : arrays) {
            for (String element : array) {
                if (element != null) {
                    combinedArray[currentIndex] = element;
                    currentIndex++;
                }
            }
        }

        return combinedArray;
    }

    public static void alphabeticalSort(String[] array) {
        for (int i = 0; i < array.length - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < array.length; j++) {
                if (array[j] != null && (array[minIndex] == null || compareStrings(array[j], array[minIndex]) < 0)) {
                    minIndex = j;
                }
            }
            swap(array, i, minIndex);
        }
    }

    public static int compareStrings(String str1, String str2) {
        if (str1 == null && str2 == null) {
            return 0;
        } else if (str1 == null) {
            return -1;
        } else if (str2 == null) {
            return 1;
        }

        int len1 = str1.length();
        int len2 = str2.length();
        int lim = Math.min(len1, len2);

        for (int i = 0; i < lim; i++) {
            char ch1 = str1.charAt(i);
            char ch2 = str2.charAt(i);
            if (ch1 != ch2) {
                return ch1 - ch2;
            }
        }

        return len1 - len2;
    }

    public static void swap(String[] array, int i, int j) {
        String temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    static void VIEW_CUSTOMERS(){

        String[] allElements = combineArrays(CUSTOMER_POSITION_1, CUSTOMER_POSITION_2, CUSTOMER_POSITION_3);
        alphabeticalSort(allElements);

        for (String element : allElements) {
            System.out.println(element + " ");
        }

    }



    static void COUNT_OF_BURGERS(){

        System.out.println(BURGER_IN_STOCK + "-BURGERS ARE REMAIN");

    }

    static void BURGER_ADDING(){
        System.out.println("");
        System.out.println("=================================================================");
        System.out.println("--------------40 BURGERS ARE ADDED TO THE STOCK------------------");
        System.out.println("---YOU CAN PRESS THE (108 OR STK) TO VIEW THE NEW BURGER STOCK---");
        System.out.println("=================================================================");
        System.out.println("");
        BURGER_IN_STOCK += 40;

    }


    static void ADDING_DATA_TO_FILE(){
        try {
            File customerDetails = new File("FOODIES_DOCUMENT.txt");
            FileWriter Details = new FileWriter(customerDetails);

            Details.write("-*-*-*-*-*-*-*-*-*-*FOODIES FAVE QUEUE MANAGEMENT SYSTEM*-*-*-*-*-*-*-*-*-*-");
            Details.write("\n");


            for(int i = 0; i<CUSTOMER_POSITION_1.length; i++){
                if (CUSTOMER_POSITION_1[i] != null) {
                    Details.write(CUSTOMER_POSITION_1[i]);
                    Details.write(" CUSTOMER POSITION :"+"" + "CASHIER_1 : "+"" + " PLACE : " + (i+1));
                    Details.write("\n");
                }

            }


            for(int i = 0; i<CUSTOMER_POSITION_2.length; i++){
                if (CUSTOMER_POSITION_2[i] != null) {
                    Details.write(CUSTOMER_POSITION_2[i]);
                    Details.write(" CUSTOMER POSITION :"+"" + "CASHIER_2 : " +""+ " PLACE : " + (i+1));
                    Details.write("\n");
                }

            }

            for(int i = 0; i<CUSTOMER_POSITION_3.length; i++){
                if (CUSTOMER_POSITION_3[i] != null) {
                    Details.write(CUSTOMER_POSITION_3[i]);
                    Details.write(" CUSTOMER POSITION :" +""+ "CASHIER_3 : " + ""+" PLACE : " + (i+1));
                    Details.write("\n");
                }

            }


            Details.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("--------------DATA STORED SUCCESSFULLY------------------");

    }


    static void READING_FILE_DATA(){

        try {

            File customerDetails = new File("FOODIES_DOCUMENT.txt");

            Scanner ReadDetails = new Scanner(customerDetails);

            while (ReadDetails.hasNextLine()) {
                String data = ReadDetails.nextLine();
                System.out.println(data);
            }
            ReadDetails.close();

        }catch (FileNotFoundException e) {
            System.out.println("--------------ERROR------------------");
            e.printStackTrace();
        }


    }

    static void EXIT(){

        RUN_PROGRAMME = false;
        System.out.println("");
        System.out.println("--------------------HAVE A GOOD DAY---------------------");
        System.out.println("");
    }

    //Method for select item from the menu


    static void MENU(){

        Scanner input = new Scanner(System.in);

        System.out.println("--------------------WELCOME TO OUR SHOP---------------------");
        System.out.println("");
        System.out.println("PLEASE ENTER THE NUMBER OR CODE WHAT YOU WANT TO DO : ");
        String object = input.next();

        switch(object){

            case "100":
            case "VFQ":
                VIEW_ALL_QUEUE();
                break;
            case "101":
            case "VEQ":
                VIEW_EMPTY_QUEUE();
                break;
            case "102":
            case "ACQ":
                ADD_CUSTOMER();
                break;
            case "103":
            case "RCQ":
                REMOVE_CUSTOMER();
                break;
            case "104":
            case "PCQ":
                REMOVE_SERVED_CUSTOMERS();
                break;
            case "105":
            case "VCS":
                VIEW_CUSTOMERS();
                break;
            case "106":
            case "SPD":
                ADDING_DATA_TO_FILE();
                break;
            case "107":
            case "LPD":
                READING_FILE_DATA();
                break;
            case "108":
            case "STK":
                COUNT_OF_BURGERS();
                break;
            case "109":
            case "AFS":
                BURGER_ADDING();
                break;
            case "999":
            case "EXIT":
                EXIT();
                break;
            default:
                System.out.println("-WRONG-INPUT-");
        }


    }



    public static void main(String[] args) {









        System.out.println("");
        System.out.println("-*-*-*-*-*-*-*-*-*-*FOODIES FAVE QUEUE MANAGEMENT SYSTEM*-*-*-*-*-*-*-*-*-*-");
        System.out.println("");


        System.out.println("||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
        System.out.println("||--------------------------MENU------------------------------||");
        System.out.println("||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
        System.out.println("||  100 or VFQ: View all Queues.                              ||");
        System.out.println("||  101 or VEQ: View all Empty Queues.                        ||");
        System.out.println("||  102 or ACQ: Add customer to a Queue.                      ||");
        System.out.println("||  103 or RCQ: Remove a customer from a Queue.               ||");
        System.out.println("||  104 or PCQ: Remove a served customer.                     ||");
        System.out.println("||  105 or VCS: View Customers Sorted in alphabetical order.  ||");
        System.out.println("||  106 or SPD: Store Program Data into file.                 ||");
        System.out.println("||  107 or LPD: Load Program Data from file.                  ||");
        System.out.println("||  108 or STK: View Remaining burgers Stock.                 ||");
        System.out.println("||  109 or AFS: Add burgers to Stock.                         ||");
        System.out.println("||  999 or EXT: Exit the Program.                             ||");
        System.out.println("||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");

        System.out.println("");

        while (RUN_PROGRAMME) {

            if(BURGER_IN_STOCK == 10){
                System.out.println("|||||||||||||||||||WARNING||||||||||||||||||||||");
                System.out.println("BURGER STOCK ARE LOW.....PLEASE REFILL THE STOCKS");
                System.out.println("************************************************");
            }


            MENU();



        }





    }



}