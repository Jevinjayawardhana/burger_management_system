public class CUSTOMER {

    private String FIRST_NAME;
    private String LAST_NAME;
    private int REQUIRED_BURGER_COUNT;

    public CUSTOMER(String FIRST_NAME, String LAST_NAME, int REQUIRED_BURGER_COUNT) {

        this.FIRST_NAME = FIRST_NAME;
        this.LAST_NAME = LAST_NAME;
        this.REQUIRED_BURGER_COUNT = REQUIRED_BURGER_COUNT;
    }

    public String GET_FIRST_NAME() {
        return FIRST_NAME;
    }

    public String GET_LAST_NAME() {
        return LAST_NAME;
    }

    public int GET_REQUIRED_BURGER_COUNT() {
        return REQUIRED_BURGER_COUNT;
    }


}
