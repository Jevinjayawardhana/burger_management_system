package com.example.task_04_gui;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

import static com.example.task_04_gui.CLASS_VERSION.*;

public class HelloController {

    @FXML
    private Label CUSTOMER_NAME_01_01;

    @FXML
    private Label CUSTOMER_NAME_01_02;

    @FXML
    private Label CUSTOMER_NAME_02_01;

    @FXML
    private Label CUSTOMER_NAME_02_02;

    @FXML
    private Label CUSTOMER_NAME_02_03;

    @FXML
    private Label CUSTOMER_NAME_03_01;

    @FXML
    private Label CUSTOMER_NAME_03_02;

    @FXML
    private Label CUSTOMER_NAME_03_03;

    @FXML
    private Label CUSTOMER_NAME_03_04;

    @FXML
    private Label CUSTOMER_NAME_03_05;

    @FXML
    private Label INCOME_01;

    @FXML
    private Label INCOME_02;

    @FXML
    private Label INCOME_03;


    @FXML
    private Label WAITING_01;

    @FXML
    private Label WAITING_02;

    @FXML
    private Label WAITING_03;

    @FXML
    private Label WAITING_04;

    @FXML
    private Label WAITING_05;

    @FXML
    private Button WAITING_LIST;

    @FXML
    private Button SEARCH;

    @FXML
    private Button UPDATE_BUTTON;

    @FXML
    private TextArea search_id;
    @FXML
    private TextArea NAME;

    @FXML
    protected void UPDATE() {
        for (int i = 0; i < 4; i++) {
            if (i == 0) {
                if (CASHIER_POSITION[0][0] == null) {
                    CUSTOMER_NAME_01_01.setText("X");

                } else {
                    CUSTOMER_NAME_01_01.setText("O -" + CASHIER_POSITION[0][0].GET_FIRST_NAME() + " " + CASHIER_POSITION[0][0].GET_LAST_NAME());
                }

                if (CASHIER_POSITION[0][1] == null) {
                    CUSTOMER_NAME_01_02.setText("X");

                } else {
                    CUSTOMER_NAME_01_02.setText("O -" + CASHIER_POSITION[0][1].GET_FIRST_NAME() + " " + CASHIER_POSITION[0][1].GET_LAST_NAME());
                }
            } else if (i == 1) {
                if (CASHIER_POSITION[1][0] == null) {
                    CUSTOMER_NAME_02_01.setText("X");
                } else {
                    CUSTOMER_NAME_02_01.setText("O -" + CASHIER_POSITION[1][0].GET_FIRST_NAME() + " " + CASHIER_POSITION[1][0].GET_LAST_NAME());
                }
                if (CASHIER_POSITION[1][1] == null) {
                    CUSTOMER_NAME_02_02.setText("X");
                } else {
                    CUSTOMER_NAME_02_02.setText("O -" + CASHIER_POSITION[1][1].GET_FIRST_NAME() + " " + CASHIER_POSITION[1][1].GET_LAST_NAME());
                }
                if (CASHIER_POSITION[1][2] == null) {
                    CUSTOMER_NAME_02_03.setText("X");
                } else {
                    CUSTOMER_NAME_02_03.setText("O -" + CASHIER_POSITION[1][2].GET_FIRST_NAME() + " " + CASHIER_POSITION[1][2].GET_LAST_NAME());
                }
            } else if (i == 2) {
                if (CASHIER_POSITION[2][0] == null) {
                    CUSTOMER_NAME_03_01.setText("X");
                } else {
                    CUSTOMER_NAME_03_01.setText("O -" + CASHIER_POSITION[2][0].GET_FIRST_NAME() + " " + CASHIER_POSITION[2][0].GET_LAST_NAME());
                }
                if (CASHIER_POSITION[2][1] == null) {
                    CUSTOMER_NAME_03_02.setText("X");
                } else {
                    CUSTOMER_NAME_03_02.setText("O -" + CASHIER_POSITION[2][1].GET_FIRST_NAME() + " " + CASHIER_POSITION[2][1].GET_LAST_NAME());
                }
                if (CASHIER_POSITION[2][2] == null) {
                    CUSTOMER_NAME_03_03.setText("X");
                } else {
                    CUSTOMER_NAME_03_03.setText("O -" + CASHIER_POSITION[2][2].GET_FIRST_NAME() + " " + CASHIER_POSITION[2][2].GET_LAST_NAME());
                }
                if (CASHIER_POSITION[2][3] == null) {
                    CUSTOMER_NAME_03_04.setText("X");
                } else {
                    CUSTOMER_NAME_03_04.setText("O -" + CASHIER_POSITION[2][3].GET_FIRST_NAME() + " " + CASHIER_POSITION[2][3].GET_LAST_NAME());
                }
                if (CASHIER_POSITION[2][4] == null) {
                    CUSTOMER_NAME_03_05.setText("X");
                } else {
                    CUSTOMER_NAME_03_05.setText("O -" + CASHIER_POSITION[2][4].GET_FIRST_NAME() + " " + CASHIER_POSITION[2][4].GET_LAST_NAME());


                }

                int[] incomes = new int[3];
                incomes[0] = BURGER_COUNT_OF_QUEUE_POSITION_01 * 650;
                incomes[1] = BURGER_COUNT_OF_QUEUE_POSITION_02 * 650;
                incomes[2] = BURGER_COUNT_OF_QUEUE_POSITION_03 * 650;

                INCOME_01.setText(String.valueOf(incomes[0]));
                INCOME_02.setText(String.valueOf(incomes[1]));
                INCOME_03.setText(String.valueOf(incomes[2]));
                for (int j = 0; j < incomes.length; j++) {
                    System.out.println(" QUEUE_POSITION_0" + (j + 1) + " : " + incomes[j]);
                }


            }
        }
    }


    @FXML
    protected void search() {
        String name = search_id.getText();
        StringBuilder customerInfoBuilder = new StringBuilder();

        int customerCount = 0; // Counter for numbering customers

        for (int queueIndex = 0; queueIndex < CASHIER_POSITION.length; queueIndex++) {
            CUSTOMER[] queue = CASHIER_POSITION[queueIndex];
            for (int position = 0; position < queue.length; position++) {
                CUSTOMER customer = queue[position];
                if (customer != null && customer.GET_FIRST_NAME().equals(name)) {
                    customerCount++;
                    if (customerCount > 1) {
                        customerInfoBuilder.append("\n-----------------\n"); // Add a line separator before displaying each new customer
                    }
                    String firstName = customer.GET_FIRST_NAME();
                    String lastName = customer.GET_LAST_NAME();
                    int burgerCount = customer.GET_BURGER_COUNT();
                    String queuePosition = "Queue " + (queueIndex + 1) + ", Position " + (position + 1);
                    String customerInfo = "Customer " + customerCount + "\nFirst Name: " + firstName + "\nLast Name: " + lastName + "\nBurger Count: " + burgerCount + "\nQueue Position: " + queuePosition;
                    customerInfoBuilder.append(customerInfo).append("\n");
                }
            }
        }

        String customerInfo = customerInfoBuilder.toString();
        if (!customerInfo.isEmpty()) {
            NAME.setText(customerInfo); // Display all customers with the same name
        } else {
            NAME.setText("There are no customers with this name"); // Clear the text if no customer is found
        }
    }


    @FXML
    protected void waiting_update() {


        for (int i = 0; i < 6; i++) {
            if (i == 0) {
                if (WAITING_QUEUE_SECTION[0] == null) {
                    WAITING_01.setText("X");

                } else {
                    WAITING_01.setText("O");
                }
                if (WAITING_QUEUE_SECTION[1] == null) {
                    WAITING_02.setText("X");

                } else {
                    WAITING_02.setText("O");
                }
                if (WAITING_QUEUE_SECTION[2] == null) {
                    WAITING_03.setText("X");

                } else {
                    WAITING_03.setText("O");
                }
                if (WAITING_QUEUE_SECTION[3] == null) {
                    WAITING_04.setText("X");

                } else {
                    WAITING_04.setText("O");
                }
                if (WAITING_QUEUE_SECTION[4] == null) {
                    WAITING_05.setText("X");

                } else {
                    WAITING_05.setText("O");
                }


            }
        }
    }
}














