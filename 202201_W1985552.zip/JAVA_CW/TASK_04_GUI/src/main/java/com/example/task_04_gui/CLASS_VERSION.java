package com.example.task_04_gui;

import javafx.application.Application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Objects;
import java.util.Scanner;

public class CLASS_VERSION {

    static CUSTOMER[][] CASHIER_POSITION = new CUSTOMER[3][];
    static CUSTOMER[] WAITING_QUEUE_SECTION = new CUSTOMER[6];
    static int BURGERS_IN_STOCK = 50;
    static int SOLD_BURGER_STOCK = 0;

    static int BURGER_COUNT_OF_QUEUE_POSITION_01 = 0;
    static int BURGER_COUNT_OF_QUEUE_POSITION_02 = 0;
    static int BURGER_COUNT_OF_QUEUE_POSITION_03 = 0;

    public void QUEUE() {

        CASHIER_POSITION[0] = new CUSTOMER[2];
        CASHIER_POSITION[1] = new CUSTOMER[3];
        CASHIER_POSITION[2] = new CUSTOMER[5];
    }

    public static void VIEW_ALL_QUEUE() {            //display the cashier position and their status
        System.out.println("*****************");
        System.out.println("*-C-A-S-H-I-E-R-*");
        System.out.println("*****************");

        for (int i = 0; i < 5; i++) {
            for (CUSTOMER[] customers : CASHIER_POSITION) {
                if (i < customers.length) {
                    if (customers[i] == null) {
                        System.out.print(" X    ");
                    } else {
                        System.out.print(" O    ");
                    }
                } else {
                    System.out.print("      ");
                }
            }
            System.out.println();
        }
    }


    public void VIEW_EMPTY_QUEUE() {      //display all empty queues

        boolean EMPTY_LINE_01 = true;
        boolean EMPTY_LINE_02 = true;
        boolean EMPTY_LINE_03 = true;

        System.out.println("*****************");
        System.out.println("*-C-A-S-H-I-E-R-*");
        System.out.println("*****************");



        for (CUSTOMER[] cashierPosition : CASHIER_POSITION) {
            for (CUSTOMER element : cashierPosition) {
                if (element != null) {
                    if (cashierPosition == CASHIER_POSITION[0]) {
                        EMPTY_LINE_01 = false;
                    } else if (cashierPosition == CASHIER_POSITION[1]) {
                        EMPTY_LINE_02 = false;
                    } else if (cashierPosition == CASHIER_POSITION[2]) {
                        EMPTY_LINE_03 = false;
                    }
                    break;
                }
            }
        }


//display the X and O with checking the queues
        if(EMPTY_LINE_01 && EMPTY_LINE_02 && EMPTY_LINE_03) {
            System.out.printf("%2s %5s %6s %n", CASHIER_POSITION[0][0] != null ? "O" :
                    "X", CASHIER_POSITION[1][0] != null ? "O" : "X", CASHIER_POSITION[2][0] != null ? "O" : "X");
            System.out.printf("%2s %5s %6s %n", CASHIER_POSITION[0][1] != null ? "" :
                    "X", CASHIER_POSITION[1][1] != null ? "O" : "X", CASHIER_POSITION[2][1] != null ? "O" : "x");
            System.out.printf("%8s %6s %n", CASHIER_POSITION[1][2] != null ? "O" :
                    "X", CASHIER_POSITION[2][2] != null ? "O" : "X");
            System.out.printf("%15s %n", CASHIER_POSITION[2][3] != null ? "O" : "X");
        } else if (EMPTY_LINE_01 && EMPTY_LINE_02) {
            System.out.printf("%2s %5s %n", CASHIER_POSITION[0][0] != null ? "O" :
                    "X", CASHIER_POSITION[1][0] != null ? "O" : "X");
            System.out.printf("%2s %5s %n", CASHIER_POSITION[0][1] != null ? "O" :
                    "X", CASHIER_POSITION[1][1] != null ? "O" : "X");
            System.out.printf("%8s %n", CASHIER_POSITION[1][2] != null ? "O" : "X");
        } else if (EMPTY_LINE_01 && EMPTY_LINE_03){
            System.out.printf("%2s %12s %n", CASHIER_POSITION[0][0] != null ? "O" :
                    "X", CASHIER_POSITION[2][0] != null ? "O" : "X");

            System.out.printf("%2s %12s %n", CASHIER_POSITION[0][1] != null ? "O" :
                    "X", CASHIER_POSITION[2][1] != null ? "O" : "X");
            System.out.printf("%15s %n", CASHIER_POSITION[2][2] != null ? "O" : "x");
            System.out.printf("%15s %n", CASHIER_POSITION[2][3] != null ? "O" : "x");
            System.out.printf("%15s %n", CASHIER_POSITION[2][4] != null ? "O" : "x");
        } else if (EMPTY_LINE_02 && EMPTY_LINE_03) {
            System.out.printf("%8s %6s %n",CASHIER_POSITION[1][0] != null ? "O" :
                    "X",CASHIER_POSITION[2][0]!= null ? "O" : "X");
            System.out.printf("%8s %6s %n",CASHIER_POSITION[1][1]!= null ? "O" :
                    "X",CASHIER_POSITION[2][1]!= null ? "O" : "x");
            System.out.printf("%8s %6s %n",CASHIER_POSITION[1][2]!= null ? "O" :
                    "X",CASHIER_POSITION[2][2]!= null ? "O" : "x");
            System.out.printf("%15s %n",CASHIER_POSITION[2][3]!= null ? "O" : "X");
            System.out.printf("%15s %n",CASHIER_POSITION[2][4]!= null ? "O" : "X");
        } else if (EMPTY_LINE_01) {
            System.out.printf("%2s %n",CASHIER_POSITION[0][0]!= null ? "O" : "X");
            System.out.printf("%2s %n",CASHIER_POSITION[0][1]!= null ? "O" : "X");
        } else if (EMPTY_LINE_02) {
            System.out.printf("%8s %n",CASHIER_POSITION[1][0]!= null ? "O" : "X");
            System.out.printf("%8s %n",CASHIER_POSITION[1][1]!= null ? "O" : "X");
            System.out.printf("%8s %n",CASHIER_POSITION[1][2]!= null ? "O" : "X");
        }else {
            System.out.printf("%15s %n",CASHIER_POSITION[2][0]!= null ? "O" : "X");
            System.out.printf("%15s %n",CASHIER_POSITION[2][1]!= null ? "O" : "X");
            System.out.printf("%15s %n",CASHIER_POSITION[2][2]!= null ? "O" : "X");
            System.out.printf("%15s %n",CASHIER_POSITION[2][3]!= null ? "O" : "X");
            System.out.printf("%15s %n",CASHIER_POSITION[2][4]!= null ? "O" : "XS");
        }
        System.out.println(" X - EMPTY POSITIONS");
    }



    private static int QUEUE_LENGTH(int queue) { //checking how many customers in each queue…It's used for waiting option

        int COUNT = 0;

        if (queue == 1) {
            for (int j = 0; j < 2; j++) {
                if (CASHIER_POSITION[0][j] != null) {
                    COUNT += 1;
                }
            }
        }

        if (queue == 2) {
            for (int j = 0; j < 3; j++) {
                if (CASHIER_POSITION[1][j] != null) {
                    COUNT += 1;
                }
            }
        }

        if (queue == 3) {
            for (int j = 0; j < 5; j++) {
                if (CASHIER_POSITION[2][j] != null) {
                    COUNT += 1;
                }
            }
        }
        if (queue == 4) {
            for (int i = 0; i < 5; i++) {
                if (WAITING_QUEUE_SECTION[i] != null) {
                    COUNT += 1;
                }
            }
        }

        return COUNT;
    }

    private int TO_FIND_SMALLEST_QUEUE() {  //checking the smallest queue to add customer from waiting section
        int small_queue = 0;
        int LENGTH_OF_QUEUE_01 = QUEUE_LENGTH(1);
        int LENGTH_OF_QUEUE_02 = QUEUE_LENGTH(2);
        int LENGTH_OF_QUEUE_03 = QUEUE_LENGTH(3);

        if (LENGTH_OF_QUEUE_01 != 2 || LENGTH_OF_QUEUE_02 != 3 || LENGTH_OF_QUEUE_03 != 5) {
            if (LENGTH_OF_QUEUE_01 <= LENGTH_OF_QUEUE_03 && LENGTH_OF_QUEUE_01 != 2) {
                small_queue = 1;
            } else if (LENGTH_OF_QUEUE_02 <= LENGTH_OF_QUEUE_01 && LENGTH_OF_QUEUE_02 <= LENGTH_OF_QUEUE_03 && LENGTH_OF_QUEUE_02 != 3) {

                small_queue = 2;
            } else {
                small_queue = 3;
            }
        } else {
            System.out.println("---QUEUES ARE FULL...PLEASE WAIT---");
        }

        return small_queue;

    }


    public void ADD_CUSTOMER() { // adding customers to the queue

        Scanner input = new Scanner(System.in);

        System.out.print("PLEASE ENTER YOUR FIRST NAME : ");
        String FIRST_NAME = input.next();

        System.out.print("PLEASE ENTER YOUR LAST NAME : ");
        String LAST_NAME = input.next();

        int REQUIRED_BURGER_COUNT = 0;
        boolean VALID_INPUT = false;
        while (!VALID_INPUT) {
            System.out.print("ENTER HOW MANY BURGERS ARE YOU WANT: ");
            if (input.hasNextInt()) {
                REQUIRED_BURGER_COUNT = input.nextInt();
                VALID_INPUT = true;
            } else {
                System.out.println("/n");
                System.out.println("-WRONG-INPUT-");
                System.out.println("-PLEASE ENTER AN INTEGER-");
                System.out.println("/n");
                input.next(); // Clear the invalid input from the scanner
            }
        }

        CUSTOMER HUMAN = new CUSTOMER(FIRST_NAME, LAST_NAME, REQUIRED_BURGER_COUNT);

        if (QUEUE_LENGTH(1) == 2 && QUEUE_LENGTH(2) == 3 && QUEUE_LENGTH(3) == 5) {
            if (QUEUE_LENGTH(4) != 5) {
                for (int i = 0; i < WAITING_QUEUE_SECTION.length; i++) {
                    if (WAITING_QUEUE_SECTION[i] == null) {
                        WAITING_QUEUE_SECTION[i] = HUMAN;
                        System.out.println("\nCustomer Added to Waiting list\n");
                        break;
                    }
                }
            } else {
                System.out.println("Waiting list is full Please wait");
            }
        }

        int small_queue = TO_FIND_SMALLEST_QUEUE(); //get the information from small queue and the customers then add to the queue

        if (small_queue == 1) {
            BURGER_COUNT_OF_QUEUE_POSITION_01 += REQUIRED_BURGER_COUNT;
            for (int j = 0; j < CASHIER_POSITION[0].length; j++) {
                if (CASHIER_POSITION[0][j] == null) {
                    CASHIER_POSITION[0][j] = HUMAN;
                    break;
                }
            }
        } else if (small_queue == 2) {
            BURGER_COUNT_OF_QUEUE_POSITION_02 += REQUIRED_BURGER_COUNT;
            for (int j = 0; j < CASHIER_POSITION[1].length; j++) {
                if (CASHIER_POSITION[1][j] == null) {
                    CASHIER_POSITION[1][j] = HUMAN;
                    break;
                }
            }
        } else {
            BURGER_COUNT_OF_QUEUE_POSITION_03 += REQUIRED_BURGER_COUNT;
            for (int j = 0; j < CASHIER_POSITION[2].length; j++) {
                if (CASHIER_POSITION[2][j] == null) {
                    CASHIER_POSITION[2][j] = HUMAN;
                    break;
                }
            }
        }


        VIEW_ALL_QUEUE();

    }


    public static void REMOVE_CUSTOMER() {
        try {
            Scanner INPUT_02 = new Scanner(System.in);
            int WHAT_QUEUE;
            int WhichOne;

            // Loop until correct input is obtained for the queue number
            do {
                System.out.print("ENTER THE QUEUE NUMBER OF CUSTOMER THAT YOU WANT TO REMOVE (1, 2, 3): ");
                WHAT_QUEUE = INPUT_02.nextInt();

                if (WHAT_QUEUE > 3 || WHAT_QUEUE < 1) {
                    System.out.println("-------------");
                    System.out.println("-WRONG-INPUT-");
                    System.out.println("-------------");
                }
            } while (WHAT_QUEUE > 3 || WHAT_QUEUE < 1);

            int selectedQueueIndex = WHAT_QUEUE - 1;

            // Loop until correct input is obtained for the position number
            do {
                System.out.print("WHICH CUSTOMER (PLEASE ENTER POSITION NUMBER OF CUSTOMER):");
                WhichOne = INPUT_02.nextInt();

                if (WhichOne < 1 || WhichOne > CASHIER_POSITION[selectedQueueIndex].length) {
                    System.out.println("-----------------------");
                    System.out.println("-NO CUSTOMER TO REMOVE-");
                    System.out.println("-----------------------");
                }
            } while (WhichOne < 1 || WhichOne > CASHIER_POSITION[selectedQueueIndex].length);

            if (CASHIER_POSITION[selectedQueueIndex][WhichOne - 1] != null) {
                for (int i = WhichOne - 1; i < CASHIER_POSITION[selectedQueueIndex].length - 1; i++) {
                    CASHIER_POSITION[selectedQueueIndex][i] = CASHIER_POSITION[selectedQueueIndex][i + 1];
                }
                CASHIER_POSITION[selectedQueueIndex][CASHIER_POSITION[selectedQueueIndex].length - 1] = null;


                if (WAITING_QUEUE_SECTION[0] != null) {
                    // Add the customer from the waiting queue to the customer queue
                    CASHIER_POSITION[selectedQueueIndex][CASHIER_POSITION[selectedQueueIndex].length - 1] = WAITING_QUEUE_SECTION[0];

                    // Shift the remaining customers in the waiting queue
                    for (int j = 0; j < WAITING_QUEUE_SECTION.length - 1; j++) {
                        WAITING_QUEUE_SECTION[j] = WAITING_QUEUE_SECTION[j + 1];
                    }

                    WAITING_QUEUE_SECTION[WAITING_QUEUE_SECTION.length - 1] = null;
                }

            } else {
                System.out.println("-----------------------");
                System.out.println("-NO CUSTOMER TO REMOVE-");
                System.out.println("-----------------------");

            }


        } catch (InputMismatchException e) {
            System.out.println("-------------");
            System.out.println("-WRONG-INPUT-");
            System.out.println("-------------");
        }


        VIEW_ALL_QUEUE();
    }


    static void REMOVE_SERVED_CUSTOMERS() {
        try {
            Scanner INPUT_3 = new Scanner(System.in);
            int WHAT_QUEUE;

            // Loop until correct input is obtained for the queue number
            do {
                System.out.print("ENTER THE QUEUE NUMBER OF CUSTOMER THAT YOU WANT TO REMOVE (1, 2, 3): ");
                WHAT_QUEUE = INPUT_3.nextInt();

                if (WHAT_QUEUE > 3 || WHAT_QUEUE < 1) {
                    System.out.println("-------------");
                    System.out.println("-WRONG-INPUT-");
                    System.out.println("-------------");
                }
            } while (WHAT_QUEUE > 3 || WHAT_QUEUE < 1);

            int queueIndex = WHAT_QUEUE - 1;

            // Check if the selected queue has customers
            if (CASHIER_POSITION[queueIndex].length == 0) {
                System.out.println("-NO-CUSTOMER-TO-REMOVE-");
            } else {
                int requiredBurgerCount = CASHIER_POSITION[queueIndex][0].GET_REQUIRED_BURGER_COUNT();
                BURGERS_IN_STOCK -= requiredBurgerCount;
                SOLD_BURGER_STOCK += requiredBurgerCount;

                int customerCount = QUEUE_LENGTH(WHAT_QUEUE);

                // Shift customers in the queue
                if (customerCount > 0) {
                    for (int i = 0; i < CASHIER_POSITION[queueIndex].length - 1; i++) {
                        CASHIER_POSITION[queueIndex][i] = CASHIER_POSITION[queueIndex][i + 1];
                    }
                    CASHIER_POSITION[queueIndex][CASHIER_POSITION[queueIndex].length - 1] = null;
                } else {
                    System.out.println("-NO-CUSTOMER-TO-REMOVE-");
                }
            }

            if (WAITING_QUEUE_SECTION[0] != null) {
                CASHIER_POSITION[queueIndex][CASHIER_POSITION[queueIndex].length - 1] = WAITING_QUEUE_SECTION[0];

                for (int j = 0; j < WAITING_QUEUE_SECTION.length - 1; j++) {
                    WAITING_QUEUE_SECTION[j] = WAITING_QUEUE_SECTION[j + 1];
                }

                WAITING_QUEUE_SECTION[WAITING_QUEUE_SECTION.length - 1] = null;
            }
            else {
            System.out.println("-NO-CUSTOMER-TO-REMOVE-"); // If there are no customers in the queue
        }
        } catch (InputMismatchException e) {
            System.out.println("-------------");
            System.out.println("-WRONG-INPUT-");
            System.out.println("-------------");
        }

        VIEW_ALL_QUEUE();
    }


    static void VIEW_CUSTOMERS() {
        String[][] CUSTOMER_QUEUE_LINE = new String[3][]; // 2D array for storing customer names

        // Set sizes for 2D array elements to store customer names
        CUSTOMER_QUEUE_LINE[0] = new String[2];
        CUSTOMER_QUEUE_LINE[1] = new String[3];
        CUSTOMER_QUEUE_LINE[2] = new String[5];

        // Get data from Cashier and store it in CUSTOMER_QUEUE_LINE array
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < CASHIER_POSITION[i].length; j++) {
                if (CASHIER_POSITION[i][j] != null) {
                    CUSTOMER_QUEUE_LINE[i][j] = CASHIER_POSITION[i][j].GET_FIRST_NAME() + " " + CASHIER_POSITION[i][j].GET_LAST_NAME();
                }
            }
        }

        try {
            // Flatten the 2D array into a 1D array
            String[] FLAT_ARRAY = Arrays.stream(CUSTOMER_QUEUE_LINE)
                    .flatMap(Arrays::stream)
                    .filter(Objects::nonNull)
                    .toArray(String[]::new);

            // Bubble sort algorithm to sort customers in alphabetical order
            int n = FLAT_ARRAY.length;
            boolean swapped;

            for (int i = 0; i < n - 1; i++) {
                swapped = false;
                for (int j = 0; j < n - i - 1; j++) {
                    if (FLAT_ARRAY[j].compareTo(FLAT_ARRAY[j + 1]) > 0) {
                        // Swap FLAT_ARRAY[j] and FLAT_ARRAY[j+1]
                        String temp = FLAT_ARRAY[j];
                        FLAT_ARRAY[j] = FLAT_ARRAY[j + 1];
                        FLAT_ARRAY[j + 1] = temp;
                        swapped = true;
                    }
                }

                // If no two elements were swapped in the inner loop, the array is already sorted
                if (!swapped) {
                    break;
                }
            }

            for (String item : FLAT_ARRAY) {
                System.out.println(item);
            }
        } catch (NullPointerException e) {
            System.out.println("-NO-CUSTOMER-TO-VIEW-");
        }
    }


    static void ADDING_DATA_TO_FILE() {
        String[][] CUSTOMER_QUEUE_LINE = new String[3][]; // 2D array for storing customer names

        // Set sizes for 2D array elements to store customer names
        CUSTOMER_QUEUE_LINE[0] = new String[2];
        CUSTOMER_QUEUE_LINE[1] = new String[3];
        CUSTOMER_QUEUE_LINE[2] = new String[5];

        // Get data from Cashier and store it in CUSTOMER_QUEUE_LINE array
        for (int j = 0; j < 3; j++) {
            for (int i = 0; i < CASHIER_POSITION[j].length; i++) {
                if (CASHIER_POSITION[j][i] != null) {
                    CUSTOMER_QUEUE_LINE[j][i] = CASHIER_POSITION[j][i].GET_FIRST_NAME() + " "
                            + CASHIER_POSITION[j][i].GET_LAST_NAME() + " "
                            + CASHIER_POSITION[j][i].GET_REQUIRED_BURGER_COUNT() + " Burgers Required ";
                }
            }
        }

        try {
            File customerDetails = new File("FOODIES_DOCUMENT.txt");
            FileWriter Details = new FileWriter(customerDetails);

            Details.write("-*-*-*-*-*-*-*-*-*-*FOODIES FAVE QUEUE MANAGEMENT SYSTEM*-*-*-*-*-*-*-*-*-*-\n");

            for (int i = 0; i < CUSTOMER_QUEUE_LINE.length; i++) {
                for (int j = 0; j < CUSTOMER_QUEUE_LINE[i].length; j++) {
                    if (CUSTOMER_QUEUE_LINE[i][j] != null) {
                        Details.write(CUSTOMER_QUEUE_LINE[i][j]);
                        Details.write(" Position: Queue " + (i + 1) + " Number " + (j + 1));
                        Details.write("\n");
                    }
                }
            }

            Details.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("--------------DATA STORED SUCCESSFULLY------------------");
    }


    static void READING_FILE_DATA() {
        try {
            File customerDetails = new File("FOODIES_DOCUMENT.txt");
            Scanner readDetails = new Scanner(customerDetails);

            while (readDetails.hasNextLine()) {
                String data = readDetails.nextLine();
                System.out.println(data);
            }
            readDetails.close();
        } catch (FileNotFoundException e) {
            System.out.println("--------------ERROR------------------");
            e.printStackTrace();
        }
    }


    static void COUNT_OF_BURGERS() {  //checking the burger stock
        System.out.println(BURGERS_IN_STOCK + " BURGERS REMAIN");
        System.out.println("|||||||||||||||||||WARNING||||||||||||||||||||||");
        System.out.println("BURGER STOCK ARE LOW.....PLEASE REFILL THE STOCKS");
        System.out.println("************************************************");
    }

    static void BURGER_ADDING() {
        int minimumBurgerCount = 10;
        int additionalBurgers = 40;

        // Checking if burger count is below or equal to the minimum level
        if (BURGERS_IN_STOCK <= minimumBurgerCount) {
            BURGERS_IN_STOCK += additionalBurgers;
            System.out.println("Added " + additionalBurgers + " BURGERS TO THE STOCK.");
        } else {
            System.out.println("BURGER STOCKS ARE SUFFICIENT.");
        }
    }


    static void CALCULATE_INCOME() { //calculate income from each queues
        int[] incomes = new int[3];
        incomes[0] = BURGER_COUNT_OF_QUEUE_POSITION_01 * 650;
        incomes[1] = BURGER_COUNT_OF_QUEUE_POSITION_02 * 650;
        incomes[2] = BURGER_COUNT_OF_QUEUE_POSITION_03 * 650;

        System.out.println("===================================================");
        System.out.println("--------------INCOME FROM BURGERS------------------");
        System.out.println("===================================================");

        for (int i = 0; i < incomes.length; i++) {
            System.out.println(" QUEUE_POSITION_0" + (i + 1) + " : " + incomes[i]);
        }

        System.out.println("===================================================");
    }

    static void BURGER_WARNING() {
        //Print warning message when burger count reach 10
        if (BURGERS_IN_STOCK <= 10) {
            System.out.println("||||||||||||||||||||WARNING||||||||||||||||||||||");
            System.out.println("BURGER STOCK ARE LOW.....PLEASE REFILL THE STOCKS");
            System.out.println("*************************************************");
        }
    }
/*
    public void WAITING_QUEUE_SECTION() {
        try{
            for(int i =0 ; i < 5 ; i++){
                System.out.println(i+1 + "." + WAITING_QUEUE_SECTION[i].GET_FIRST_NAME() + "" + WAITING_QUEUE_SECTION[i].GET_LAST_NAME());
            }
        }catch (NullPointerException e ){}
    }

 */




public void WAITING_QUEUE_SECTION() {
    if (WAITING_QUEUE_SECTION == null) {
        System.out.println("The waiting section is null. Please check the input data.");
        return;
    }

    for (int i = 0; i < 6; i++) {
        if (WAITING_QUEUE_SECTION[i] != null) {
            System.out.println((i + 1) + ". " + WAITING_QUEUE_SECTION[i].GET_FIRST_NAME() + " " + WAITING_QUEUE_SECTION[i].GET_LAST_NAME());
        }
    }
}



    static void EXIT() {


        System.out.println("/n");
        System.out.println("--------------------HAVE A GOOD DAY---------------------");
        System.out.println("/n");
    }
    public void promt(){
        Application.launch(HelloApplication.class);
    }
}






