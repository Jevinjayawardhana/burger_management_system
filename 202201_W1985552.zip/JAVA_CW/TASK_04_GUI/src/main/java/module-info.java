module com.example.task_04_gui {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.task_04_gui to javafx.fxml;
    exports com.example.task_04_gui;
}